/**
 * features/games/gameHelpers.js
 * Shared constants and utility functions for all game engines.
 */

export const AVATARS_G = {
  'VeerBhat_Pro':'🦁', 'Khachi':'🐑', 'SatoshiAlpha':'🦊',
  'CryptoKhan':'🐯', 'MoonBet99':'🌙', 'You':'😎',
};

export const CARD_SUITS = ['♠','♥','♦','♣'];
export const CARD_VALS  = ['2','3','4','5','6','7','8','9','10','J','Q','K','A'];
export const CARD_RANK  = {2:0,3:1,4:2,5:3,6:4,7:5,8:6,9:7,10:8,J:9,Q:10,K:11,A:12};

// LowCard Room specific
export const LC_SUITS = ['♠','♥','♦','♣'];
export const LC_VALS  = ['2','3','4','5','6','7','8','9','10','J','Q','K','A'];
export const LC_RANK  = Object.fromEntries(LC_VALS.map((v,i)=>[v,i+1])); // A=13

export function drawRandCard() {
  const s = CARD_SUITS[Math.floor(Math.random()*4)];
  const v = CARD_VALS[Math.floor(Math.random()*13)];
  return {s, v, r: CARD_RANK[v]};
}

export function lcDraw() {
  const v = LC_VALS[Math.floor(Math.random()*13)];
  const s = LC_SUITS[Math.floor(Math.random()*4)];
  return {v, s, r: LC_RANK[v], key: v+s+Math.random()};
}

export function lcDeal5() {
  return Array.from({length:5}, () => lcDraw());
}

export function mkShuffledDeck() {
  const d = CARD_SUITS.flatMap(s => CARD_VALS.map(v => ({s, v, r: CARD_RANK[v]})));
  for (let i = d.length-1; i > 0; i--) {
    const j = Math.floor(Math.random()*(i+1));
    [d[i],d[j]] = [d[j],d[i]];
  }
  return d;
}

export function tNow() {
  return new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
}
