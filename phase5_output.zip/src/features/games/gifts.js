import { useState } from 'react';
import { Bx } from '../../components/primitives';

// ── Gift message pools ──
const GIFT_MSGS = {
  ROSE:    [(f)=>`🌹 ${f} sent you a Rose — "A rose for a radiant soul 🌹"`,(f)=>`🌹 ${f} gifted you a Rose — "Beauty deserves beauty 🌸"`,(f)=>`🌹 ${f} gave you a Rose — "Quietly saying: you're appreciated 🌹"`],
  CHILLY:  [(f)=>`🌶️ ${f} sent you a Chilly — "Too hot to handle? Thought so 😏"`,(f)=>`🌶️ ${f} gifted you a Chilly — "Things are heating up 🌶"`,(f)=>`🌶️ ${f} gave you a Chilly — "Spicy plays deserve spicy gifts 🔥"`],
  CROWN:   [(f)=>`👑 ${f} crowned you — "Royalty recognises royalty 👑"`,(f)=>`👑 ${f} sent you a Crown — "You played like a king today 🏆"`,(f)=>`👑 ${f} crowned you — "The room bows down 👑"`],
  ROCKET:  [(f)=>`🚀 ${f} sent you a Rocket — "To the moon and beyond! 🌙"`,(f)=>`🚀 ${f} gifted a Rocket — "Strap in, you're going places 🚀"`,(f)=>`🚀 ${f} launched a Rocket at you — "WAGMI 🚀🌕"`],
  TROPHY:  [(f)=>`🏆 ${f} sent you a Trophy — "You earned every bit of this 🏆"`,(f)=>`🏆 ${f} gifted a Trophy — "The room agrees — you're the best 🏆"`,(f)=>`🏆 ${f} gave you a Trophy — "This one belongs on a shelf 🏆"`],
  BOMB:    [(f)=>`💣 ${f} sent you a Bomb — "Tick tock... 💥"`,(f)=>`💣 ${f} gifted you a Bomb — "Boom goes the dynamite 💥"`,(f)=>`💣 ${f} lit a fuse and aimed at you — "Run! 💣💥"`],
  SHEEP:   [(f)=>`🐑 ${f} gifted you a Sheep — "Found your spirit animal 🐑"`,(f)=>`🐑 ${f} sent you a Sheep — "May the CUTBAR flock be with you 🐑"`,(f)=>`🐑 ${f} gave you a Sheep — "Ba-a-a-a. That's all. 🐑"`],
  RING:    [(f)=>`💍 ${f} sent you a Ring — "This is legendary 💍"`],
  DIAMOND: [(f)=>`💎 ${f} sent you a Diamond — "Only legends receive this 💎"`],
};

export function pickGiftMsg(key, from) {
  const pool = GIFT_MSGS[key] || [];
  return pool.length ? pool[Math.floor(Math.random()*pool.length)](from) : `🎁 ${from} sent you a gift!`;
}

export const GIFTS = {
  ROSE:      {emoji:'🌹', name:'Rose',      cost:100,     tier:'common',    msg:(f)=>pickGiftMsg('ROSE',f)},
  CHILLY:    {emoji:'🌶️', name:'Chilly',    cost:250,     tier:'common',    msg:(f)=>pickGiftMsg('CHILLY',f)},
  BOMB:      {emoji:'💣', name:'Bomb',       cost:500,     tier:'common',    msg:(f)=>pickGiftMsg('BOMB',f)},
  SHEEP:     {emoji:'🐑', name:'Sheep',      cost:1000,    tier:'rare',      msg:(f)=>pickGiftMsg('SHEEP',f)},
  ROCKET:    {emoji:'🚀', name:'Rocket',     cost:2500,    tier:'rare',      msg:(f)=>pickGiftMsg('ROCKET',f)},
  TROPHY:    {emoji:'🏆', name:'Trophy',     cost:5000,    tier:'epic',      msg:(f)=>pickGiftMsg('TROPHY',f)},
  CROWN:     {emoji:'👑', name:'Crown',      cost:10000,   tier:'epic',      msg:(f)=>pickGiftMsg('CROWN',f)},
  RING:      {emoji:'💍', name:'Ring',       cost:25000,   tier:'legendary', msg:(f)=>pickGiftMsg('RING',f)},
  DIAMOND:   {emoji:'💎', name:'Diamond',    cost:1000000, tier:'legendary', msg:(f)=>pickGiftMsg('DIAMOND',f)},
};

// ── Gift Marketplace Modal ──
export function GiftMarketplace({open, onClose, onSend, balance}) {
  const [selectedGift, setSelectedGift] = useState(null);
  const [targetUser,   setTargetUser]   = useState('');
  if (!open) return null;

  const TIERS = {
    common:    {label:'Common',    color:'#aaa'},
    rare:      {label:'Rare',      color:'#00e5ff'},
    epic:      {label:'Epic',      color:'#9945ff'},
    legendary: {label:'Legendary', color:'#ffd700'},
  };

  const byTier = Object.entries(GIFTS).reduce((acc,[k,g]) => {
    if (!acc[g.tier]) acc[g.tier] = [];
    acc[g.tier].push({key:k,...g});
    return acc;
  }, {});

  const handleSend = () => {
    if (!selectedGift || !targetUser.trim()) return;
    onSend(`/gift ${selectedGift.key.toLowerCase()} @${targetUser.replace('@','')}`);
    onClose();
  };

  return (
    <div onClick={e=>{if(e.target===e.currentTarget)onClose();}}
      style={{position:'fixed',inset:0,zIndex:600,background:'rgba(0,0,0,.75)',backdropFilter:'blur(6px)'}}>
      <div style={{position:'absolute',bottom:0,left:'50%',transform:'translateX(-50%)',width:'100%',maxWidth:480,background:'var(--panel)',borderRadius:'20px 20px 0 0',borderTop:'1px solid var(--bb)',maxHeight:'88vh',display:'flex',flexDirection:'column',animation:'slideUp .28s cubic-bezier(.16,1,.3,1)'}}>
        <div style={{display:'flex',justifyContent:'center',padding:'10px 0 0'}}>
          <div style={{width:36,height:4,borderRadius:2,background:'var(--b)'}}/>
        </div>
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'10px 18px 12px',borderBottom:'1px solid var(--b)'}}>
          <div>
            <div style={{fontSize:16,fontWeight:700,color:'var(--text)'}}>🎁 Gift Marketplace</div>
            <div style={{fontSize:10,color:'var(--td)',fontFamily:'var(--mono)'}}>Balance: 🐑 {balance.toLocaleString()} CUTBAR</div>
          </div>
          <div onClick={onClose} style={{width:28,height:28,borderRadius:8,background:'rgba(255,255,255,.06)',display:'flex',alignItems:'center',justifyContent:'center',cursor:'pointer',fontSize:13,color:'var(--td)'}}>✕</div>
        </div>
        <div style={{flex:1,overflowY:'auto',padding:'10px 14px'}}>
          {['common','rare','epic','legendary'].map(tier => {
            const gifts = byTier[tier]||[];
            if (!gifts.length) return null;
            const tc = TIERS[tier];
            return (
              <div key={tier} style={{marginBottom:16}}>
                <div style={{fontSize:9,fontWeight:700,color:tc.color,fontFamily:'var(--mono)',letterSpacing:2,marginBottom:8,textTransform:'uppercase'}}>{tc.label}</div>
                <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:8}}>
                  {gifts.map(g => {
                    const isSelected = selectedGift?.key===g.key;
                    const canAfford = balance >= g.cost;
                    return (
                      <div key={g.key} onClick={()=>canAfford&&setSelectedGift(isSelected?null:g)}
                        style={{borderRadius:12,padding:'12px 8px',background:isSelected?tc.color+'18':'var(--bg3)',border:`2px solid ${isSelected?tc.color:canAfford?'var(--b)':'rgba(255,255,255,.04)'}`,cursor:canAfford?'pointer':'not-allowed',opacity:canAfford?1:.45,textAlign:'center',transition:'all .15s'}}>
                        <div style={{fontSize:28,marginBottom:4}}>{g.emoji}</div>
                        <div style={{fontSize:11,fontWeight:700,color:'var(--text)',marginBottom:2}}>{g.name}</div>
                        <div style={{fontSize:9,color:tc.color,fontFamily:'var(--mono)',fontWeight:700}}>🐑 {g.cost>=1000000?'1M':g.cost>=1000?(g.cost/1000)+'K':g.cost}</div>
                        {isSelected&&<div style={{marginTop:4,fontSize:8,color:tc.color,fontFamily:'var(--mono)'}}>✓ Selected</div>}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
        {selectedGift ? (
          <div style={{padding:'12px 14px',borderTop:'1px solid var(--b)',background:'var(--bg3)'}}>
            <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:10}}>
              <span style={{fontSize:24}}>{selectedGift.emoji}</span>
              <div style={{flex:1,minWidth:0}}>
                <div style={{fontSize:12,fontWeight:700,color:'var(--text)'}}>{selectedGift.name}</div>
                <div style={{fontSize:10,color:TIERS[selectedGift.tier].color,fontFamily:'var(--mono)'}}>🐑 {selectedGift.cost.toLocaleString()} · {TIERS[selectedGift.tier].label}</div>
              </div>
            </div>
            <div style={{display:'flex',gap:8}}>
              <input value={targetUser} onChange={e=>setTargetUser(e.target.value)} placeholder="Username (without @)"
                style={{flex:1,background:'var(--bg)',border:'1px solid var(--b)',color:'var(--text)',fontFamily:'var(--body)',fontSize:13,borderRadius:10,padding:'9px 12px',outline:'none'}}
                onFocus={e=>e.target.style.borderColor='var(--g)'} onBlur={e=>e.target.style.borderColor='var(--b)'}/>
              <button onClick={handleSend} disabled={!targetUser.trim()}
                style={{padding:'9px 16px',borderRadius:10,border:'none',cursor:targetUser.trim()?'pointer':'not-allowed',background:targetUser.trim()?`linear-gradient(135deg,${TIERS[selectedGift.tier].color}99,${TIERS[selectedGift.tier].color})`:'var(--b)',color:'#000',fontSize:12,fontWeight:700,flexShrink:0,opacity:targetUser.trim()?1:.5}}>
                Send 🎁
              </button>
            </div>
          </div>
        ) : (
          <div style={{padding:'12px 14px',borderTop:'1px solid var(--b)',textAlign:'center'}}>
            <span style={{fontSize:11,color:'var(--td)',fontFamily:'var(--mono)'}}>Tap a gift to select, then choose who to send it to</span>
          </div>
        )}
      </div>
    </div>
  );
}
