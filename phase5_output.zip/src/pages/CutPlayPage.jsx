/* eslint-disable react-hooks/exhaustive-deps */
import { useState, useRef, useEffect, useMemo } from 'react';
import { BackBar, Bx, Btn } from '../components/primitives';
import { PnlBar, LowCardOutGame, DiceCricketGame, PenaltyShootoutGame, BotKabaddiGame, BlindArcherGame, CutbarJungGame, KokarFightGame, TaekwondoGame } from '../components/GameEngines';
import { tNow, drawRandCard, AVATARS_G } from '../features/games/gameHelpers';
import { GiftMarketplace } from '../features/games/gifts';

// ─────────────────────────────────────────────────────────────
// CUTPLAY PAGE — Game Lobby
// ─────────────────────────────────────────────────────────────
export function CutPlayPage({ toast, onBack }) {
  const [screen,       setScreen]       = useState('lobby');
  const [selectedRoom, setSelectedRoom] = useState(null);
  const [bet,          setBet]          = useState(50);
  const [balance,      setBalance]      = useState(5000);
  const [pnl,          setPnl]          = useState(0);
  const [showBet,      setShowBet]      = useState(false);
  const [filter,       setFilter]       = useState('all');
  const [instantJoin,  setInstantJoin]  = useState(false);

  const rooms = [
    {id:'lowcard',  icon:'🃏',name:'LowCardOut',        desc:'Lowest card each round is eliminated',   players:12,minBet:25, color:'#ff7a00',tag:'LIVE',    win:32,risk:68},
    {id:'laststand',icon:'⚔️',name:'Last Standing',     desc:'Text-command chatroom battle royale',    players:8, minBet:5,  color:'#9945ff',tag:'CHATROOM',win:22,risk:78},
    {id:'dice',     icon:'🎲',name:'T10 Dice Cricket',  desc:'Roll dice · 5=wicket · 6=six',           players:8, minBet:50, color:'#00e5ff',tag:'LIVE',    win:38,risk:62},
    {id:'8ball',    icon:'🎱',name:'8Ball Cricket',      desc:'Predict every ball of the over',         players:6, minBet:25, color:'#b44fff',tag:'HOT 🔥', win:28,risk:72},
    {id:'penalty',  icon:'🥅',name:'Penalty Shootout',  desc:'Pick Left / Centre / Right — 5 kicks',  players:18,minBet:25, color:'#ffd700',tag:'JACKPOT', win:35,risk:65},
    {id:'kabaddi',  icon:'🤸',name:'Bot Kabaddi',        desc:'Raid, tag, escape — reverse kabaddi',   players:14,minBet:25, color:'#00cc88',tag:'BETA',    win:30,risk:70},
    {id:'archer',   icon:'🏹',name:'Blind Archer',       desc:'Feel the wind — angle + power = score', players:10,minBet:50, color:'#ffd700',tag:'SKILL',   win:26,risk:74},
    {id:'jung',     icon:'🐑',name:'Cutbar Jung',        desc:'Your 🐑 vs Bot 🐑 — Horn Battle',       players:11,minBet:25, color:'#ff7a00',tag:'FIGHT',   win:40,risk:60},
    {id:'kokar',    icon:'🐓',name:'Kokar Fight',        desc:'CLAW > PECK > DODGE > CLAW',            players:9, minBet:25, color:'#ff3b5c',tag:'BRUTAL',  win:33,risk:67},
    {id:'taekwondo',icon:'🥋',name:'Taekwondo',          desc:'Kung Fu + Martial Arts · 3 round match', players:7, minBet:50, color:'#9945ff',tag:'LIVE',    win:25,risk:75},
  ];

  const FILTERS = [['all','All'],['popular','🔥 Popular'],['highwin','💰 High Win'],['highrisk','⚠️ High Risk']];
  const filteredRooms = useMemo(()=>{
    let r=[...rooms];
    if(filter==='popular')   r=r.sort((a,b)=>b.players-a.players);
    else if(filter==='highwin')  r=r.sort((a,b)=>b.win-a.win);
    else if(filter==='highrisk') r=r.sort((a,b)=>b.risk-a.risk);
    return r;
  },[filter]);

  const handlePnl = delta => { setPnl(p=>p+delta); setBalance(b=>b+delta); };
  const featured = rooms[0];

  // Game screens
  if (screen==='game' && selectedRoom?.id==='lowcard') return <LastStandingWrapper title="LowCardOut 🃏" onBack={()=>setScreen('lobby')} GameComponent={LowCardOutGame} bet={bet} toast={toast} onPnl={handlePnl}/>;
  if (screen==='game' && selectedRoom?.id==='laststand') return <LastStandingPage toast={toast} onBack={()=>setScreen('lobby')}/>;

  if (screen==='game' && selectedRoom) return (
    <div style={{display:'flex',flexDirection:'column',height:'100vh',background:'var(--bg)',maxWidth:480,margin:'0 auto'}}>
      <div style={{display:'flex',alignItems:'center',padding:'8px 14px',borderBottom:'1px solid var(--bb)',background:'var(--header)',flexShrink:0,gap:10}}>
        <div onClick={()=>setScreen('lobby')} style={{width:32,height:32,borderRadius:9,background:'rgba(0,0,0,.18)',border:'1px solid rgba(255,255,255,.08)',display:'flex',alignItems:'center',justifyContent:'center',cursor:'pointer',flexShrink:0}}>
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M9 2L4 7L9 12" stroke="var(--text)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </div>
        <div style={{flex:1}}><div style={{fontSize:13,fontWeight:800}}>{selectedRoom.icon} {selectedRoom.name}</div><div style={{fontSize:9,color:'var(--td)',fontFamily:'var(--mono)'}}>🐑 {bet} · {pnl!==0&&<span style={{color:pnl>0?'var(--g)':'var(--red)'}}>{pnl>0?'+':''}{pnl}</span>}</div></div>
        <Bx color="gold" style={{fontSize:8}}>🐑 {bet}</Bx>
      </div>
      <div style={{padding:'7px 12px',borderBottom:'1px solid var(--b)',flexShrink:0,background:'var(--bg)'}}>
        {!showBet?(
          <button onClick={()=>setShowBet(true)} style={{width:'100%',padding:'8px',borderRadius:9,background:`rgba(0,229,255,.08)`,border:`1px solid ${selectedRoom.color}44`,color:selectedRoom.color,fontFamily:'var(--display)',fontSize:12,letterSpacing:.3,cursor:'pointer'}}>+ START NEW ROUND · 🐑 {bet}</button>
        ):(
          <div>
            <div style={{display:'flex',gap:7,alignItems:'center',marginBottom:6}}>
              <span style={{fontSize:10,color:'var(--td)',fontFamily:'var(--mono)',flexShrink:0}}>BET</span>
              <input type="number" min="1" max="100000" value={bet} onChange={e=>setBet(parseInt(e.target.value)||bet)} style={{flex:1,background:'var(--bg3)',border:'1px solid var(--b)',color:'var(--text)',fontFamily:'var(--mono)',fontSize:13,borderRadius:8,padding:'6px 10px',outline:'none'}}/>
              <button onClick={()=>setShowBet(false)} style={{padding:'6px 12px',borderRadius:8,background:`linear-gradient(135deg,${selectedRoom.color}99,${selectedRoom.color})`,border:'none',color:'#000',fontFamily:'var(--display)',fontSize:11,cursor:'pointer',fontWeight:700}}>SET</button>
              <button onClick={()=>setShowBet(false)} style={{padding:'6px 9px',borderRadius:8,background:'transparent',border:'1px solid var(--b)',color:'var(--td)',fontSize:11,cursor:'pointer'}}>✕</button>
            </div>
            <div style={{display:'flex',gap:4}}>
              {[25,50,100,250,500,1000,2500,5000].map(b=>(
                <div key={b} onClick={()=>{setBet(b);setShowBet(false);}} style={{flex:1,padding:'4px 1px',textAlign:'center',borderRadius:6,background:bet===b?selectedRoom.color+'22':'var(--bg3)',border:'1px solid '+(bet===b?selectedRoom.color+'66':'var(--b)'),color:bet===b?selectedRoom.color:'var(--td)',fontSize:8,fontFamily:'var(--mono)',cursor:'pointer',fontWeight:700}}>{b>=1000?b/1000+'K':b}</div>
              ))}
            </div>
          </div>
        )}
      </div>
      <div style={{flex:1,minHeight:0,overflow:'hidden',display:'flex',flexDirection:'column'}}>
        {selectedRoom.id==='dice'     && <DiceCricketGame    toast={toast} bet={bet} onPnl={handlePnl}/>}
        {selectedRoom.id==='penalty'  && <PenaltyShootoutGame toast={toast} bet={bet} onPnl={handlePnl}/>}
        {selectedRoom.id==='kabaddi'  && <BotKabaddiGame     toast={toast} bet={bet} onPnl={handlePnl}/>}
        {selectedRoom.id==='archer'   && <BlindArcherGame    toast={toast} bet={bet} onPnl={handlePnl}/>}
        {selectedRoom.id==='jung'     && <CutbarJungGame     toast={toast} bet={bet} onPnl={handlePnl}/>}
        {selectedRoom.id==='kokar'    && <KokarFightGame     toast={toast} bet={bet} onPnl={handlePnl}/>}
        {selectedRoom.id==='taekwondo'&& <TaekwondoGame      toast={toast} bet={bet} onPnl={handlePnl}/>}
      </div>
    </div>
  );

  // PREGAME screen
  if (screen==='pregame' && selectedRoom) return (
    <div className="fu" style={{paddingBottom:80}}>
      <BackBar title={`${selectedRoom.icon} ${selectedRoom.name}`} onBack={()=>setScreen('lobby')}/>
      <div style={{margin:'10px 14px',background:`linear-gradient(135deg,${selectedRoom.color}18,${selectedRoom.color}06)`,border:`1px solid ${selectedRoom.color}40`,borderRadius:16,padding:18}}>
        <div style={{fontSize:11,color:'var(--td)',marginBottom:8,lineHeight:1.7}}>{selectedRoom.desc}</div>
        <div style={{display:'flex',gap:6,flexWrap:'wrap',marginBottom:12}}>
          <Bx style={{background:selectedRoom.color+'18',color:selectedRoom.color,borderColor:selectedRoom.color+'30',fontSize:9}}>{selectedRoom.tag}</Bx>
          <Bx color="green" style={{fontSize:9}}>{selectedRoom.players} online</Bx>
          <Bx color="gold" style={{fontSize:9}}>Min 🐑 {selectedRoom.minBet}</Bx>
        </div>
        <div style={{display:'flex',gap:8,marginBottom:12}}>
          <div style={{flex:1}}><div style={{fontSize:8,color:'var(--g)',fontFamily:'var(--mono)',marginBottom:3}}>WIN RATE</div><div style={{height:6,borderRadius:3,background:'var(--b)'}}><div style={{width:selectedRoom.win+'%',height:'100%',background:'var(--g)',borderRadius:3}}/></div><div style={{fontSize:9,color:'var(--g)',fontFamily:'var(--mono)',marginTop:2}}>{selectedRoom.win}%</div></div>
          <div style={{flex:1}}><div style={{fontSize:8,color:'var(--red)',fontFamily:'var(--mono)',marginBottom:3}}>RISK</div><div style={{height:6,borderRadius:3,background:'var(--b)'}}><div style={{width:selectedRoom.risk+'%',height:'100%',background:'var(--red)',borderRadius:3}}/></div><div style={{fontSize:9,color:'var(--red)',fontFamily:'var(--mono)',marginTop:2}}>{selectedRoom.risk}%</div></div>
        </div>
      </div>
      <div style={{padding:'0 14px 10px'}}>
        <div style={{fontSize:9,color:'var(--td)',fontFamily:'var(--mono)',letterSpacing:2,marginBottom:8}}>SELECT BET</div>
        <div style={{display:'flex',gap:6,flexWrap:'wrap',marginBottom:12}}>
          {[25,50,100,250,500,1000].map(b=>(
            <div key={b} onClick={()=>setBet(b)} style={{padding:'7px 12px',borderRadius:9,border:`1px solid ${bet===b?selectedRoom.color:'var(--b)'}`,background:bet===b?selectedRoom.color+'18':'var(--bg3)',color:bet===b?selectedRoom.color:'var(--td)',fontSize:11,fontFamily:'var(--mono)',fontWeight:700,cursor:'pointer'}}>🐑 {b}</div>
          ))}
        </div>
        <button onClick={()=>setScreen('game')} style={{width:'100%',padding:'16px',borderRadius:14,background:`linear-gradient(135deg,${selectedRoom.color}dd,${selectedRoom.color})`,border:'none',color:'#000',fontFamily:'var(--display)',fontSize:18,letterSpacing:1,cursor:'pointer',boxShadow:`0 8px 28px ${selectedRoom.color}55`,fontWeight:700}}>
          🔥 Join the Thrill
        </button>
      </div>
    </div>
  );

  // LOBBY
  return (
    <div className="fu" style={{paddingBottom:80}}>
      <BackBar title="cutPlay 🎮" onBack={onBack} right={<span style={{fontSize:9,color:'var(--gold)',fontFamily:'var(--mono)',fontWeight:700}}>🐑 {balance.toLocaleString()}</span>}/>
      {pnl!==0&&<PnlBar pnl={pnl}/>}

      {/* Featured */}
      <div onClick={()=>{setBet(Math.max(bet,featured.minBet));setSelectedRoom(featured);setScreen('pregame');}}
        style={{margin:'8px 14px 10px',padding:'14px',background:`linear-gradient(135deg,${featured.color}18,${featured.color}06)`,border:`2px solid ${featured.color}60`,borderRadius:16,cursor:'pointer',position:'relative',overflow:'hidden'}}>
        <div style={{position:'absolute',right:8,top:8,fontSize:8,fontFamily:'var(--mono)',fontWeight:800,color:featured.color,background:featured.color+'20',border:`1px solid ${featured.color}40`,borderRadius:20,padding:'2px 8px',letterSpacing:1}}>🔥 FEATURED</div>
        <div style={{display:'flex',alignItems:'center',gap:12}}>
          <div style={{width:54,height:54,borderRadius:14,background:featured.color+'22',display:'flex',alignItems:'center',justifyContent:'center',fontSize:28,border:`2px solid ${featured.color}50`,flexShrink:0}}>{featured.icon}</div>
          <div style={{flex:1}}><div style={{fontSize:15,fontWeight:800,marginBottom:3}}>{featured.name}</div><div style={{fontSize:10,color:'var(--td)',marginBottom:6}}>{featured.desc}</div><div style={{display:'flex',gap:6,alignItems:'center'}}><div style={{width:5,height:5,borderRadius:'50%',background:featured.color,animation:'pulse 1s infinite'}}/><span style={{fontSize:9,color:'var(--td)',fontFamily:'var(--mono)'}}>{featured.players} online · min 🐑 {featured.minBet}</span></div></div>
          <div style={{padding:'10px 14px',borderRadius:10,background:`linear-gradient(135deg,${featured.color},${featured.color}aa)`,color:'#000',fontSize:11,fontWeight:900,flexShrink:0,fontFamily:'var(--mono)'}}>PLAY NOW</div>
        </div>
      </div>

      {/* Filters */}
      <div style={{padding:'0 14px 8px'}}>
        <div style={{display:'flex',gap:6,overflowX:'auto',paddingBottom:4,marginBottom:8}}>
          {FILTERS.map(([k,l])=>(
            <div key={k} onClick={()=>setFilter(k)} style={{flexShrink:0,padding:'5px 11px',borderRadius:20,border:`1px solid ${filter===k?'var(--bb)':'var(--b)'}`,background:filter===k?'rgba(0,255,65,.1)':'var(--panel)',fontSize:10,color:filter===k?'var(--g)':'var(--td)',cursor:'pointer',fontFamily:'var(--mono)',fontWeight:700,whiteSpace:'nowrap'}}>{l}</div>
          ))}
        </div>
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'8px 12px',background:'var(--panel)',border:`1px solid ${instantJoin?'var(--bb)':'var(--b)'}`,borderRadius:10}}>
          <div><div style={{fontSize:11,fontWeight:700,color:instantJoin?'var(--g)':'var(--text)'}}>⚡ Instant Join</div><div style={{fontSize:9,color:'var(--td)',fontFamily:'var(--mono)'}}>Auto-join next available round</div></div>
          <div onClick={()=>setInstantJoin(v=>!v)} style={{width:46,height:24,borderRadius:12,background:instantJoin?'var(--g)':'var(--b)',position:'relative',cursor:'pointer',transition:'background .3s',border:'1px solid var(--bb)'}}>
            <div style={{position:'absolute',top:3,left:instantJoin?22:3,width:16,height:16,borderRadius:'50%',background:instantJoin?'#000':'var(--td)',transition:'left .3s'}}/>
          </div>
        </div>
      </div>

      {/* Game cards */}
      <div style={{display:'flex',flexDirection:'column',gap:8,padding:'0 14px 14px'}}>
        {filteredRooms.map(r=>(
          <div key={r.id} onClick={()=>{setBet(Math.max(bet,r.minBet));setSelectedRoom(r);setScreen('pregame');}}
            style={{background:'var(--panel)',border:`1px solid var(--b)`,borderRadius:14,padding:'12px 14px',cursor:'pointer',display:'flex',alignItems:'center',gap:12,position:'relative',overflow:'hidden',transition:'border-color .2s'}}
            onMouseEnter={e=>e.currentTarget.style.borderColor=r.color+'55'}
            onMouseLeave={e=>e.currentTarget.style.borderColor='var(--b)'}>
            <div style={{width:44,height:44,borderRadius:12,background:r.color+'18',display:'flex',alignItems:'center',justifyContent:'center',fontSize:22,border:`1px solid ${r.color}28`,flexShrink:0}}>{r.icon}</div>
            <div style={{flex:1}}>
              <div style={{display:'flex',gap:6,alignItems:'center',marginBottom:2}}><span style={{fontSize:13,fontWeight:800}}>{r.name}</span><Bx style={{fontSize:7,background:r.color+'15',color:r.color,borderColor:r.color+'30'}}>{r.tag}</Bx></div>
              <div style={{fontSize:10,color:'var(--td)'}}>{r.desc}</div>
            </div>
            <div style={{textAlign:'right',flexShrink:0}}>
              <div style={{fontSize:10,color:'var(--g)',fontFamily:'var(--mono)',fontWeight:700}}>{r.win}% win</div>
              <div style={{fontSize:9,color:'var(--td)',fontFamily:'var(--mono)'}}>{r.players} online</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// Wrapper for LowCardOut with full-screen layout
function LastStandingWrapper({ title, onBack, GameComponent, bet, toast, onPnl }) {
  return (
    <div style={{display:'flex',flexDirection:'column',height:'100vh',background:'var(--bg)',maxWidth:480,margin:'0 auto'}}>
      <div style={{display:'flex',alignItems:'center',padding:'8px 14px',borderBottom:'1px solid var(--bb)',background:'var(--header)',flexShrink:0,gap:10}}>
        <div onClick={onBack} style={{width:32,height:32,borderRadius:9,background:'rgba(0,0,0,.18)',border:'1px solid rgba(255,255,255,.08)',display:'flex',alignItems:'center',justifyContent:'center',cursor:'pointer'}}>
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M9 2L4 7L9 12" stroke="var(--text)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </div>
        <div style={{fontSize:13,fontWeight:800,flex:1}}>{title}</div>
        <Bx color="gold" style={{fontSize:8}}>🐑 {bet}</Bx>
      </div>
      <div style={{flex:1,minHeight:0,overflow:'hidden',display:'flex',flexDirection:'column'}}>
        <GameComponent toast={toast} bet={bet} onPnl={onPnl}/>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// LAST STANDING PAGE — Chatroom command game
// ─────────────────────────────────────────────────────────────
export function LastStandingPage({ toast, onBack }) {
  const PLATFORM_FEE=0.04; const JOIN_SECS=60; const DRAW_SECS=20;
  const MY='You'; const BOTS=['VeerBhat_Pro','Khachi','SatoshiAlpha','CryptoKhan','MoonBet99'];
  const [msgs,   setMsgs]   = useState([{type:'sys',text:'⚔️ Welcome to Last Standing Wins! Type !start 0.05 to begin.',color:'var(--cyan)'},{type:'sys',text:'💡 Aces HIGH · Lowest card OUT · Winner takes pot minus 4% fee',color:'var(--td)'}]);
  const [input,  setInput]  = useState('');
  const [bal,    setBal]    = useState(100.00);
  const [game,   setGame]   = useState(null);
  const [showStart, setShowStart] = useState(false);
  const [betInput,  setBetInput]  = useState('50');
  const [showGiftMarket, setShowGiftMarket] = useState(false);
  const chatRef=useRef(null);const joinTRef=useRef(null);const drawTRef=useRef(null);const idleRef=useRef(null);const gameRef=useRef(null);
  gameRef.current=game;
  useEffect(()=>{if(chatRef.current)chatRef.current.scrollTop=chatRef.current.scrollHeight;},[msgs]);
  useEffect(()=>{startIdle();return()=>{clearTimeout(joinTRef.current);clearTimeout(drawTRef.current);clearTimeout(idleRef.current);};},[]);

  const addM=(m)=>setMsgs(p=>[...p,{...m,t:tNow()}]);
  const addSys=(text,color='var(--td)')=>addM({type:'sys',text,color});
  const addPriv=(text,color='var(--red)')=>addM({type:'priv',text,color});
  const addUser=(user,text)=>addM({type:'user',user,text});
  const startIdle=()=>{clearTimeout(idleRef.current);idleRef.current=setTimeout(()=>{const g=gameRef.current;if(!g||g.phase==='done')addSys('💤 Room is quiet. Type !start 0.05 to kick off!','var(--cyan)');},10*60*1000);};

  const resolveRound=(players,bet,pot,round)=>{
    const active=players.filter(p=>!p.elim);
    const minR=Math.min(...active.map(p=>p.card.r));
    const losers=active.filter(p=>p.card.r===minR);
    if(losers.length>1){
      addSys('⚡ TIE between '+losers.map(p=>p.name).join(' & ')+'! They draw again.','var(--gold)');
      const rp=players.map(p=>losers.find(l=>l.name===p.name)?{...p,card:null}:{...p});
      setGame(g=>g?{...g,players:rp,phase:'tiebreak'}:g);
      losers.filter(p=>p.isBot).forEach((p,i)=>{setTimeout(()=>{const c=drawRandCard();addSys('🃏 '+p.name+' drew: '+c.v+c.s,'var(--text)');setGame(g=>{if(!g)return g;const np=g.players.map(pl=>pl.name===p.name?{...pl,card:c}:pl);const all=np.filter(x=>!x.elim).every(x=>x.card);if(all)setTimeout(()=>resolveRound(np,bet,pot,round),400);return{...g,players:np};});},i*1000+500+Math.random()*800);});
      return;
    }
    const loser=losers[0];addSys('💀 '+loser.name+' drew '+loser.card.v+loser.card.s+' — KNOCKED OUT!','var(--red)');
    const np=players.map(p=>p.name===loser.name?{...p,elim:true}:{...p,card:null});
    const stillIn=np.filter(p=>!p.elim);
    if(stillIn.length<=1){
      const winner=stillIn[0];if(!winner){setGame(g=>g?{...g,phase:'done'}:g);return;}
      const fee=+(pot*PLATFORM_FEE).toFixed(2);const win=+(pot-fee).toFixed(2);
      addSys('🏆 '+winner.name+' is LAST STANDING! Pot $'+pot.toFixed(2)+' · Fee $'+fee+' (4%) · Winner gets $'+win,'var(--gold)');
      if(winner.name===MY){setBal(b=>+(b+win).toFixed(2));toast('🏆 YOU WIN! +$'+win);}else toast('😔 '+winner.name+' won $'+win);
      setGame(g=>g?{...g,players:np,phase:'done'}:g);return;
    }
    addSys('🔄 Round '+(round+1)+'! '+stillIn.length+' players remain. Type !d within '+DRAW_SECS+'s!','var(--cyan)');
    setGame(g=>g?{...g,players:np,round:round+1,phase:'drawing'}:g);
    stillIn.filter(p=>p.isBot).forEach((p,i)=>{setTimeout(()=>{const c=drawRandCard();addSys('🃏 '+p.name+' drew: '+c.v+c.s,'var(--text)');setGame(g=>{if(!g)return g;const up=g.players.map(pl=>pl.name===p.name?{...pl,card:c}:pl);const all=up.filter(x=>!x.elim).every(x=>x.card);if(all){clearTimeout(drawTRef.current);setTimeout(()=>resolveRound(up,bet,pot,round+1),400);}return{...g,players:up};});},i*1200+600+Math.random()*1500);});
    clearTimeout(drawTRef.current);drawTRef.current=setTimeout(()=>{setGame(g=>{if(!g||g.phase==='done')return g;const need=g.players.filter(p=>!p.elim&&!p.card);let upd={...g,players:[...g.players]};need.forEach(p=>{const c=drawRandCard();upd={...upd,players:upd.players.map(pl=>pl.name===p.name?{...pl,card:c}:pl)};addSys((p.name===MY?'⚡ Auto-drew for you':'🤖 Bot drew for '+p.name)+': '+c.v+c.s,'var(--td)');});const all=upd.players.filter(x=>!x.elim).every(x=>x.card);if(all)setTimeout(()=>resolveRound(upd.players,g.betAmt||0.05,g.pot,round+1),400);return upd;});},DRAW_SECS*1000);
  };

  const startGame=(betAmt)=>{
    clearTimeout(joinTRef.current);clearTimeout(drawTRef.current);setBal(b=>+(b-betAmt).toFixed(2));
    const players=[{name:MY,card:null,elim:false,isBot:false}];const g={phase:'joining',betAmt,pot:betAmt,round:1,players};setGame(g);
    addSys('🃏 '+MY+' has started a $'+betAmt.toFixed(2)+' game! Type !j within '+JOIN_SECS+' seconds.','var(--g)');
    const delays=[5000,11000,19000,28000,41000];
    delays.forEach((delay,bi)=>{if(Math.random()>0.3){setTimeout(()=>{setGame(prev=>{if(!prev||prev.phase!=='joining')return prev;const name=BOTS[bi];addSys('🃏 '+name+' joined the game!','var(--g)');return{...prev,pot:+(prev.pot+betAmt).toFixed(2),players:[...prev.players,{name,card:null,elim:false,isBot:true}]};});},delay);}});
    joinTRef.current=setTimeout(()=>{setGame(prev=>{if(!prev||prev.phase!=='joining')return prev;if(prev.players.length<2){addSys('❌ Not enough players. Game cancelled. Full refund.','var(--red)');setBal(b=>+(b+betAmt).toFixed(2));return{...prev,phase:'done'};}
    addSys('🚀 GAME STARTED! '+prev.players.length+' players · Pot: $'+prev.pot.toFixed(2)+' · Type !d within '+DRAW_SECS+'s!','var(--gold)');
    const np={...prev,phase:'drawing'};np.players.filter(p=>p.isBot).forEach((p,i)=>{setTimeout(()=>{const c=drawRandCard();addSys('🃏 '+p.name+' drew: '+c.v+c.s,'var(--text)');setGame(g=>{if(!g)return g;const upd=g.players.map(pl=>pl.name===p.name?{...pl,card:c}:pl);const all=upd.filter(x=>!x.elim).every(x=>x.card);if(all){clearTimeout(drawTRef.current);setTimeout(()=>resolveRound(upd,betAmt,np.pot,1),400);}return{...g,players:upd};});},i*1300+900+Math.random()*1200);});
    clearTimeout(drawTRef.current);drawTRef.current=setTimeout(()=>{setGame(g=>{if(!g||g.phase==='done')return g;const need=g.players.filter(p=>!p.elim&&!p.card);let upd={...g,players:[...g.players]};need.forEach(p=>{const c=drawRandCard();upd={...upd,players:upd.players.map(pl=>pl.name===p.name?{...pl,card:c}:pl)};addSys((p.name===MY?'⚡ Auto-drew for you':'🤖 Bot drew for '+p.name)+': '+c.v+c.s,'var(--td)');});const all=upd.players.filter(x=>!x.elim).every(x=>x.card);if(all)setTimeout(()=>resolveRound(upd.players,betAmt,np.pot,1),400);return upd;});},DRAW_SECS*1000);
    return np;});},JOIN_SECS*1000);
  };

  const sendCmd=(raw)=>{
    const cmd=raw.trim();if(!cmd)return;startIdle();addUser(MY,cmd);setInput('');const lower=cmd.toLowerCase();
    if(lower==='!s'||lower.startsWith('!s ')||lower==='!start'||lower.startsWith('!start ')){
      const g=gameRef.current;if(g&&g.phase!=='done'){addPriv('⚠️ A game is already running.');return;}
      const parts=cmd.split(/\s+/);let betAmt=0.05;if(parts[1]){betAmt=parseFloat(parts[1]);if(isNaN(betAmt)||betAmt<=0){addPriv('⚠️ Invalid amount. Example: !start 0.10');return;}}
      if(bal<betAmt){addPriv('⚠️ Insufficient funds. Balance: $'+bal.toFixed(2));return;}startGame(betAmt);return;
    }
    if(lower==='!j'||lower==='!join'){
      const g=gameRef.current;if(!g||g.phase==='done'){addPriv('⚠️ No active game. Type !start to begin.');return;}
      if(g.phase!=='joining'){addPriv('⚠️ Game is running. Wait for next game.');return;}
      if(g.players.find(p=>p.name===MY)){addPriv("⚠️ You're already in!");return;}
      if(bal<g.betAmt){addPriv('⚠️ Insufficient funds.');return;}
      setBal(b=>+(b-g.betAmt).toFixed(2));setGame(prev=>prev?{...prev,pot:+(prev.pot+prev.betAmt).toFixed(2),players:[...prev.players,{name:MY,card:null,elim:false,isBot:false}]}:prev);
      addSys('✅ '+MY+' joined! Pot: $'+((game?.pot||0)+( game?.betAmt||0)).toFixed(2),'var(--g)');return;
    }
    if(lower==='!d'||lower==='!draw'){
      const g=gameRef.current;if(!g||(g.phase!=='drawing'&&g.phase!=='tiebreak')){addPriv('⚠️ No draw phase active.');return;}
      const me=g.players.find(p=>p.name===MY);if(!me||me.elim){addPriv("⚠️ You're out.");return;}if(me.card){addPriv('⚠️ Already drawn.');return;}
      const c=drawRandCard();const isRed=c.s==='♥'||c.s==='♦';addSys('🃏 You drew: '+c.v+c.s+(isRed?' ♥':''),'var(--g)');
      setGame(g=>{if(!g)return g;const up=g.players.map(p=>p.name===MY?{...p,card:c}:p);const all=up.filter(x=>!x.elim).every(x=>x.card);if(all){clearTimeout(drawTRef.current);setTimeout(()=>resolveRound(up,g.betAmt||0.05,g.pot,g.round),400);}return{...g,players:up};});return;
    }
    if(lower.startsWith('/tip ')){const parts=cmd.split(/\s+/);const amt=parseFloat(parts[1]);const target=(parts[2]||'').replace('@','');if(!target||isNaN(amt)||amt<=0){addPriv('⚠️ Usage: /tip 0.5 @User');return;}if(bal<amt){addPriv('⚠️ Insufficient balance.');return;}setBal(b=>+(b-amt).toFixed(2));addSys('💸 You tipped '+target+' $'+amt.toFixed(2)+'!','var(--g)');return;}
    if(lower.startsWith('/rain ')){const amt=parseFloat(cmd.split(/\s+/)[1]);if(isNaN(amt)||amt<=0){addPriv('⚠️ Usage: /rain 5');return;}if(bal<amt){addPriv('⚠️ Insufficient balance.');return;}setBal(b=>+(b-amt).toFixed(2));addSys('🌧 '+MY+' rained $'+amt.toFixed(2)+' — split equally among 5 players!','var(--g)');return;}
  };

  const me=game?.players?.find(p=>p.name===MY);

  return(
    <div style={{display:'flex',flexDirection:'column',height:'100vh',background:'var(--bg)',maxWidth:480,margin:'0 auto'}}>
      <GiftMarketplace open={showGiftMarket} onClose={()=>setShowGiftMarket(false)} onSend={sendCmd} balance={bal*1000}/>
      <div style={{display:'flex',alignItems:'center',padding:'8px 14px',borderBottom:'1px solid var(--bb)',background:'var(--header)',flexShrink:0,gap:10}}>
        <div onClick={onBack} style={{width:32,height:32,borderRadius:9,background:'rgba(0,0,0,.18)',border:'1px solid rgba(255,255,255,.08)',display:'flex',alignItems:'center',justifyContent:'center',cursor:'pointer'}}>
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M9 2L4 7L9 12" stroke="var(--text)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </div>
        <div style={{flex:1}}><div style={{fontSize:13,fontWeight:800}}>⚔️ Last Standing Wins</div><div style={{fontSize:9,color:'var(--td)',fontFamily:'var(--mono)'}}>Balance: ${bal.toFixed(2)}</div></div>
        {game&&game.phase!=='done'&&<Bx color="green" style={{fontSize:8}}>{game.players.length}P · ${game.pot.toFixed(2)}</Bx>}
      </div>

      {game&&game.phase!=='done'&&(
        <div style={{overflowX:'auto',padding:'6px 12px',background:'var(--panel)',borderBottom:'1px solid var(--b)',display:'flex',gap:8,flexShrink:0}}>
          {game.players.map(p=>(
            <div key={p.name} style={{flexShrink:0,display:'flex',flexDirection:'column',alignItems:'center',gap:2,opacity:p.elim?.3:1}}>
              <div style={{width:28,height:28,borderRadius:'50%',background:p.elim?'rgba(255,59,92,.1)':p.card?'rgba(0,255,65,.15)':'rgba(0,255,65,.06)',border:'2px solid '+(p.elim?'var(--red)':p.card?'var(--g)':'var(--b)'),display:'flex',alignItems:'center',justifyContent:'center',fontSize:13}}>{AVATARS_G[p.name]||'👤'}</div>
              <span style={{fontSize:8,color:p.elim?'var(--red)':p.name===MY?'var(--g)':'var(--td)',fontFamily:'var(--mono)',fontWeight:700}}>{p.name===MY?'YOU':p.name.split('_')[0]}</span>
              {p.card&&!p.elim&&<span style={{fontSize:8,fontFamily:'var(--mono)',color:p.card.s==='♥'||p.card.s==='♦'?'#ff9999':'var(--text)',fontWeight:700}}>{p.card.v}{p.card.s}</span>}
              {p.elim&&<span style={{fontSize:7,color:'var(--red)'}}>💀</span>}
            </div>
          ))}
        </div>
      )}

      {game&&(game.phase==='drawing'||game.phase==='tiebreak')&&me&&!me.elim&&!me.card&&(
        <div style={{padding:'6px 12px',background:'rgba(255,215,0,.04)',borderBottom:'1px solid rgba(255,215,0,.2)',flexShrink:0}}>
          <button onClick={()=>sendCmd('!d')} style={{width:'100%',padding:'10px',borderRadius:10,background:'linear-gradient(135deg,#aa8800,var(--gold))',border:'none',color:'#000',fontFamily:'var(--display)',fontSize:14,fontWeight:800,cursor:'pointer',letterSpacing:.5}}>🃏 DRAW YOUR CARD</button>
        </div>
      )}

      {(!game||game.phase==='done')&&(
        <div style={{padding:'8px 12px',borderBottom:'1px solid var(--b)',flexShrink:0}}>
          {!showStart?(
            <button onClick={()=>setShowStart(true)} style={{width:'100%',padding:'9px',borderRadius:10,background:'rgba(153,69,255,.1)',border:'1px solid rgba(153,69,255,.3)',color:'#b57aff',fontFamily:'var(--display)',fontSize:13,letterSpacing:.5,cursor:'pointer'}}>⚔️ START NEW ROUND</button>
          ):(
            <div>
              <div style={{display:'flex',gap:8,alignItems:'center',marginBottom:6}}>
                <span style={{fontSize:10,color:'var(--td)',fontFamily:'var(--mono)',flexShrink:0}}>BET</span>
                <input type="number" min="1" max="10000" value={betInput} onChange={e=>setBetInput(e.target.value)} style={{flex:1,background:'var(--bg3)',border:'1px solid var(--b)',color:'var(--text)',fontFamily:'var(--mono)',fontSize:13,borderRadius:9,padding:'7px 10px',outline:'none'}}/>
                <button onClick={()=>{const amt=(parseInt(betInput)||50)/1000;if(bal<amt){addPriv('⚠️ Insufficient balance');return;}setShowStart(false);startGame(amt);}} style={{padding:'7px 14px',borderRadius:9,background:'linear-gradient(135deg,#6611aa,#9945ff)',border:'none',color:'#fff',fontFamily:'var(--display)',fontSize:12,cursor:'pointer',flexShrink:0}}>GO</button>
                <button onClick={()=>setShowStart(false)} style={{padding:'7px 10px',borderRadius:9,background:'transparent',border:'1px solid var(--b)',color:'var(--td)',fontSize:11,cursor:'pointer',flexShrink:0}}>✕</button>
              </div>
              <div style={{display:'flex',gap:5}}>
                {[10,25,50,100,250,500,1000,2500].map(b=>(
                  <div key={b} onClick={()=>setBetInput(String(b))} style={{flex:1,padding:'5px 2px',textAlign:'center',borderRadius:7,background:betInput===String(b)?'rgba(153,69,255,.2)':'var(--bg3)',border:'1px solid '+(betInput===String(b)?'rgba(153,69,255,.5)':'var(--b)'),color:betInput===String(b)?'#b57aff':'var(--td)',fontSize:9,fontFamily:'var(--mono)',cursor:'pointer',fontWeight:700}}>{b}</div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      <div ref={chatRef} style={{flex:1,overflowY:'auto',padding:'10px 12px',display:'flex',flexDirection:'column',gap:5}}>
        {msgs.map((m,i)=>{
          if(m.type==='sys') return(
            <div key={i} style={{padding:'5px 10px',borderRadius:8,background:m.color==='var(--red)'?'rgba(255,59,92,.06)':m.color==='var(--gold)'?'rgba(255,215,0,.06)':m.color==='var(--g)'?'rgba(0,255,65,.06)':'rgba(0,229,255,.04)',border:'1px solid '+(m.color==='var(--red)'?'rgba(255,59,92,.15)':m.color==='var(--gold)'?'rgba(255,215,0,.12)':m.color==='var(--g)'?'rgba(0,255,65,.12)':'rgba(0,229,255,.08)'),alignSelf:'center',maxWidth:'96%',textAlign:'center'}}>
              <span style={{fontSize:10,color:m.color||'var(--td)',fontFamily:'var(--mono)'}}>{m.text}</span>
              {m.t&&<span style={{fontSize:8,color:'var(--td)',fontFamily:'var(--mono)',opacity:.6,marginLeft:6}}>{m.t}</span>}
            </div>
          );
          if(m.type==='priv') return(
            <div key={i} style={{alignSelf:'flex-end',padding:'5px 10px',background:'rgba(255,59,92,.08)',border:'1px solid rgba(255,59,92,.2)',borderRadius:8,maxWidth:'90%'}}>
              <span style={{fontSize:10,color:m.color||'var(--red)',fontFamily:'var(--mono)'}}>🔒 {m.text}</span>
            </div>
          );
          if(m.type==='user'){const isMe=m.user===MY;return(
            <div key={i} style={{alignSelf:isMe?'flex-end':'flex-start',maxWidth:'80%'}}>
              {!isMe&&<span style={{fontSize:9,color:'var(--td)',fontFamily:'var(--mono)',display:'block',marginBottom:2}}>{m.user}</span>}
              <div style={{padding:'6px 10px',borderRadius:isMe?'10px 3px 10px 10px':'3px 10px 10px 10px',background:isMe?'rgba(0,255,65,.1)':'var(--panel2)',border:'1px solid '+(isMe?'rgba(0,255,65,.2)':'var(--b)'),color:isMe?'var(--g)':'var(--text)',fontSize:11,fontFamily:'var(--mono)',display:'flex',flexWrap:'wrap',gap:5,alignItems:'flex-end'}}>
                <span style={{flex:1}}>{m.text}</span>
                {m.t&&<span style={{fontSize:8,color:'var(--td)',opacity:.7,flexShrink:0,lineHeight:1.8}}>{m.t}</span>}
              </div>
            </div>
          );}
          return null;
        })}
      </div>

      <div style={{display:'flex',gap:5,padding:'4px 12px 3px',overflowX:'auto',flexShrink:0,borderTop:'1px solid var(--b)'}}>
        {game&&game.phase==='joining'&&!game.players.find(p=>p.name===MY)&&(
          <div onClick={()=>sendCmd('!j')} style={{flexShrink:0,padding:'4px 14px',borderRadius:12,border:'1px solid var(--bb)',background:'rgba(0,255,65,.12)',color:'var(--g)',fontSize:10,cursor:'pointer',fontFamily:'var(--mono)',fontWeight:800}}>⚔️ !join</div>
        )}
        {game&&(game.phase==='drawing'||game.phase==='tiebreak')&&me&&!me.elim&&!me.card&&(
          <div onClick={()=>sendCmd('!d')} style={{flexShrink:0,padding:'4px 14px',borderRadius:12,border:'1px solid var(--gold)',background:'rgba(255,215,0,.1)',color:'var(--gold)',fontSize:10,cursor:'pointer',fontFamily:'var(--mono)',fontWeight:800}}>🃏 !draw</div>
        )}
        {['GG! 🃏','Lucky 😎','LFG 🔥','Rip 💀','gg wp'].map(q=>(
          <div key={q} onClick={()=>sendCmd(q)} style={{flexShrink:0,padding:'4px 10px',borderRadius:12,border:'1px solid var(--b)',background:'var(--panel)',color:'var(--td)',fontSize:9,cursor:'pointer',fontFamily:'var(--body)',fontWeight:700,whiteSpace:'nowrap'}}>{q}</div>
        ))}
      </div>
      <div style={{display:'flex',gap:5,padding:'3px 12px 3px',overflowX:'auto',flexShrink:0}}>
        {['/rain 100','/tip 0.5 @User'].map(c=>(
          <div key={c} onClick={()=>setInput(c)} style={{flexShrink:0,padding:'3px 8px',borderRadius:12,border:'1px solid var(--bb)',background:'rgba(0,255,65,.04)',color:'var(--td)',fontSize:9,cursor:'pointer',fontFamily:'var(--mono)',whiteSpace:'nowrap'}}>{c}</div>
        ))}
        <div onClick={()=>setShowGiftMarket(true)} style={{flexShrink:0,padding:'3px 10px',borderRadius:12,border:'1px solid rgba(255,215,0,.3)',background:'rgba(255,215,0,.08)',color:'var(--gold)',fontSize:9,cursor:'pointer',fontFamily:'var(--mono)',fontWeight:700}}>🎁 Gifts</div>
      </div>
      <div style={{display:'flex',gap:7,padding:'7px 12px 10px',flexShrink:0,background:'var(--bg)',borderTop:'1px solid var(--b)'}}>
        <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==='Enter'&&sendCmd(input)}
          placeholder="!start 0.05 · !j · !d · or just chat..."
          style={{flex:1,background:'var(--bg3)',border:'1px solid var(--b)',color:'var(--text)',fontFamily:'var(--mono)',fontSize:12,borderRadius:20,padding:'9px 14px',outline:'none'}}/>
        <button onClick={()=>sendCmd(input)} style={{width:38,height:38,borderRadius:'50%',background:'linear-gradient(135deg,var(--g2),var(--g))',border:'none',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M1 8L13 2L9 8M13 2L9 14L9 8" stroke="#000" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </button>
      </div>
    </div>
  );
}
